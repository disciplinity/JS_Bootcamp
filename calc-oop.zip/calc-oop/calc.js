const OPERATION_DIVISION       = 'divide'
const OPERATION_ADDITION       = 'addition'
const OPERATION_SUBTRACTION    = 'subtraction'
const OPERATION_MULTIPLICATION = 'multiplication'
const OPERATION_EQUALS         = 'equals'

const INPUT_TOO_LONG_MESSAGE = 'Too long!'
const DIGITS_TO_DISPLAY_LIMIT = 20


let firstNumber   = ''
let secondNumber  = ''
let commaEnabled  = false
let operation     = null
let repeatingOp   = null

let result = document.getElementById('result')

function setInputNumber(button) {
    
    if (result.innerText === INPUT_TOO_LONG_MESSAGE) { return }
    if (tooLong(firstNumber) || tooLong(secondNumber)) {
        result.innerText = INPUT_TOO_LONG_MESSAGE
        return
    }

    if (!operation) {
        if (firstNumber.length === 0 && button.innerText === '0') { return }
        firstNumber += button.innerText
        result.innerText = firstNumber

    } else {
        if (secondNumber.length === 0 && button.innerText === '0') { return }
        secondNumber += button.innerText
        result.innerText = secondNumber       
    }

}

function setOperation(op) {

    if (repeatingOp && repeatingOp !== op) {
        operation = op
        secondNumber = ''
        setCommaEnabled(false)
        repeatingOp = null
        return
    }


    if (firstNumber.length > 0 && secondNumber.length > 0 && operation) {
        switch (operation) {
            case OPERATION_DIVISION:
                firstNumber = (parseFloat(firstNumber) / parseFloat(secondNumber)).toString()
                break;
            case OPERATION_ADDITION:
                firstNumber = (parseFloat(firstNumber) + parseFloat(secondNumber)).toString()
                break;
            case OPERATION_SUBTRACTION:
                firstNumber = (parseFloat(firstNumber) - parseFloat(secondNumber)).toString()
                break;
            case OPERATION_MULTIPLICATION:
                firstNumber = (parseFloat(firstNumber) * parseFloat(secondNumber)).toString()
                break;
            default:
                alert('Unrecognizable operation: ' + operation)
        }
        result.innerText = firstNumber
    }

    if (op !== OPERATION_EQUALS) {
        operation = op
        secondNumber = ''
        setCommaEnabled(false)
        repeatingOp = null
    } else {
        repeatingOp = op
    }

}

function setCommaEnabled(enable) {
    console.log(`enable: ${enable} , commaenabled: ${commaEnabled}, result: ${result.innerText}`)
    if (enable && !commaEnabled && result.innerText.indexOf('.') === -1) {
        result.innerText += '.'
        secondNumber.length === 0 ? firstNumber += '.' : secondNumber += '.'
        // operation ? secondNumber += '.' : firstNumber += '.'
    }
    commaEnabled = enable

}

function tooLong(result) {
    return result.length > DIGITS_TO_DISPLAY_LIMIT
}



